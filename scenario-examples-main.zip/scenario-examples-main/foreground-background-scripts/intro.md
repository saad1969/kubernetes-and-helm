
> <strong>Note</strong>: logs of the *intro* background script can be found at `/var/log/killercoda`

<br>

Here we see that the foreground script waits for the background script to finish.
