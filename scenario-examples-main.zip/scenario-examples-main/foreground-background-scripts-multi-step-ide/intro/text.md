
> <strong>Note</strong>: logs of the *intro* background script can be found at `/var/log/killercoda`

<br>

What an Intro! It even greets us in the terminal!
