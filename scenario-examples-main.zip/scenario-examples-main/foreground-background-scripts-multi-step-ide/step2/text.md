
<br>

And to complete this step just create the file `/tmp/step2`:

```
touch /tmp/step2
```{{exec}}
