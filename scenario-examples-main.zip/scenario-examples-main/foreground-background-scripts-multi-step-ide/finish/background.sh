sleep 3
echo done > /tmp/background3
