#!/bin/bash

kubectl get pod my-pod
