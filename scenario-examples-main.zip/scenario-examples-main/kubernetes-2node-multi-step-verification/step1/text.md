
Create a pod called `my-pod`
