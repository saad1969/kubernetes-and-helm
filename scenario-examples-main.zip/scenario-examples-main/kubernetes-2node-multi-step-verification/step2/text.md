
Delete the pod called `my-pod`
