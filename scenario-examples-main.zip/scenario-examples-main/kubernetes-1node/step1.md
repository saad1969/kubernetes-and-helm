
Run `k get pod -A`
