
<br>

### Welcome !

In this scenario we'll learn how to update the `apt` repository.

**HAVE FUN**
