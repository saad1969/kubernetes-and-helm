<br>

Select the Theia IDE as default interface.
