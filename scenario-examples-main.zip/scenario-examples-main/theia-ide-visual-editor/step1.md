
> Users can always select the Editor tab to use Theia.
> But this scenario shows how to select it by default when opening a scenario.

### Send a command into the Theia Terminal
`pwd`{{exec}}
