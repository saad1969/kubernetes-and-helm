
### Display image from parent directory
![Scan results](../../assets/logo.png)


### Display image from parent directory with size
<img src="../../assets/logo.png" style="width: 50px">


### Display image

![Scan results](./yellow.png)


### Display image from subdirectory

![Scan results](./assets/blue.png)


### Display images with static size, also larger than content area
<img src="./green.png" style="width: 1000px; height: 50px; max-width: none">
