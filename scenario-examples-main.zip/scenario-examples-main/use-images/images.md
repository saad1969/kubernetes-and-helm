
### Display image from parent directory
![Scan results](../assets/logo.png)


### Display image from parent directory with size
<img src="../assets/logo.png" style="width: 50px">


### Display image

![Scan results](./image2.png)


### Display image from subdirectory

![Scan results](./assets/image1.png)


### Display images with size

<img src="./image3.png" width="100px">
