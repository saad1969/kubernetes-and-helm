For grouping scenarios into courses check https://github.com/killercoda/scenario-examples-courses
