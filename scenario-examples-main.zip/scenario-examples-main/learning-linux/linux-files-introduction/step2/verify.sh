#!/bin/bash

cat /etc/my-second-file | grep amazing
