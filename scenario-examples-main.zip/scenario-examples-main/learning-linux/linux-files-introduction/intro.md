Learn some basic commands to work with files on a Linux system
