
Now we're getting serious! Delete the file `/var/dont-need-this.png`

<br>

### Solution
Check if the file is there using

```plain
ls /var/dont-need-this.png
```{{exec}}

Now to delete we run

```plain
rm /var/dont-need-this.png
```{{exec}}
