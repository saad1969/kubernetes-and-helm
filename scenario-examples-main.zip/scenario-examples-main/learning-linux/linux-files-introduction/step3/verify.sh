#!/bin/bash

if stat /var/dont-need-this.png; then exit 1; fi
