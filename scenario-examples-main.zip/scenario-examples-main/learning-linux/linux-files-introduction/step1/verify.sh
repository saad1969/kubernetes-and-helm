#!/bin/bash

stat /root/my-new-file
