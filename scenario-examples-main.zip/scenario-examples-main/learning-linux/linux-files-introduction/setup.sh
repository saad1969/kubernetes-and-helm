touch /var/dont-need-this.png
