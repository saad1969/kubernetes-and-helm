#!/bin/bash

cat /my/location/conf.yaml
