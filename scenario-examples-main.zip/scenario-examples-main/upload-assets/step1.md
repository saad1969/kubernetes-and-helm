
Exec `/my/location/run.sh`{{exec}}
