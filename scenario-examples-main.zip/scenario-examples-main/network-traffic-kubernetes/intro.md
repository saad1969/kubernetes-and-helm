Access services running inside a Kubernetes environment
