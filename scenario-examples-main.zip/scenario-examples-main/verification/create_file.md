
Create file `/etc/panda`
