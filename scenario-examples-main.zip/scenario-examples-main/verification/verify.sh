#!/bin/bash

stat /etc/panda
