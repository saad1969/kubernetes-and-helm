
<br>

Let's learn how users can copy or exec code blocks

