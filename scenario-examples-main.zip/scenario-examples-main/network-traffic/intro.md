Access services running inside an environment
