
<br>

```
howTo() {
    includeCode("snippets");
}
```
