Run and access the Kubernetes Dashboard
